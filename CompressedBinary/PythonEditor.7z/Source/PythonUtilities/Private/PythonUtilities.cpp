//Copyright 2019, Jorge Calleros Ramirez (Karma), All rights reserved.

#include "PythonUtilities.h"


#define LOCTEXT_NAMESPACE "FPythonUtilitiesModule"

void FPythonUtilitiesModule::StartupModule()
{

}

void FPythonUtilitiesModule::ShutdownModule()
{

}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FPythonUtilitiesModule, PythonUtilities)
